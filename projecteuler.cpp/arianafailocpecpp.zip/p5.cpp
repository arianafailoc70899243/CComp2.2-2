#include <iostream>

using namespace std;
int main(){
    unsigned long long num;
    for(unsigned long long i = 1; i<300000000;i++){
        bool divisible = true;
        for(unsigned long long j = 1; j<= 20;j++){
           if(i%j != 0){
                divisible = false;
           }
        }
        if(divisible){
            num = i;
            break;
        }
    }
    cout<<"el numero es "<<num<<endl;
return 0;
}