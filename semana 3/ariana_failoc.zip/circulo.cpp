#include <iostream>
using namespace std;

int main(){

    int pi = 3.1415;
    int r = 12;
    int diam = r*2 ;
    int area = pi * (r*r);
    int cir = 2*pi*r;

    cout<<"El diametro del circulo es: "<<diam<<endl;
    cout<<"El area del circulo es: "<<area<<endl;
    cout<<"La circunferencia es: "<<cir<<endl;




    return 0;
}