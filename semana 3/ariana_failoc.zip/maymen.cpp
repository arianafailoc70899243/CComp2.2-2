#include <iostream>
using namespace std;

int main(){

int a = 10;
int b = 8;
int c = 6;
int d = 4;
int e = 2;

if (a>b and a>c and a>d and a>e){
    cout<<"el mayor numero es: "<<a<<endl;   
}
if (e<a and e<b and e<c and e<d){
    cout<<"el menor numero es: "<<e<<endl;   
}
 return 0;

}